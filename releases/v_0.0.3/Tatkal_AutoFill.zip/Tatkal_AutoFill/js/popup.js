$(function(){
	// TODO: get current targeted ticket in UI
	chrome.storage.sync.get(['booking_default'], function(result) {
		v = result.booking_default;
		if(v !== null){
			temp = {
				hash: btoa(v.booking_form_name),
				form_name: v.booking_form_name,
				from: ((v.from_station || '-').split('-')[1]).trim(),
				to: ((v.to_station || '-').split('-')[1]).trim(),
				train_no: v.train.split(":")[0].trim(),
				train_name: v.train.split(":")[1],
				j_date: v.j_date,
				j_day: months[(new Date(v.j_date)).getDay()],
				psgn_count: v.psngr.A.length,
				psgn_ch_count: v.psngr.C.length,
				class:v.coach_class,
				quota: quota[v.booking_quota]
			};
			html_temp = card_tmpl;
			$.each(temp, function(k,v){
				pattern = '{{' + k + '}}';
				regEx = new RegExp(pattern, 'g');
				html_temp = html_temp.replace(regEx, v);
			});

			$('#active_booking').html('').append(html_temp);

			$('[data-action="edit"]').click(function(){
				if(true === extention_status){
					hash = $(this).attr('data-hash');
					chrome.tabs.create({
						url:chrome.runtime.getURL('html/booking_form.html?hash='+hash),
						active: true
					});
				}
			});

			$('[data-action="delete"]').click(function(){
				if(true === extention_status){
					req_hash = $(this).attr('data-hash');
					this_ = this;
					chrome.storage.sync.get(['booking_data'], function(result) {
						bd = result.booking_data;
						delete bd[req_hash];
						keys = Object.keys(bd);
						if(keys.length == 0){
							chrome.storage.sync.set({"booking_default": {}, "booking_data": {}}, function(){
								updatePendingView();
								$(this_).closest('.card').parent().remove();
							});
						}
						else if(keys.length > 0){
							hash = keys[keys.length - 1];
							active_booking = bd[hash];
							chrome.storage.sync.set({"booking_default": active_booking, "booking_data": bd}, function(){
								updatePendingView();
								$(this_).closest('.card').parent().remove();
							});
						}
					});
				}

			});

			$('[data-action="triggerBooking"]').click(function(){
				if(true === extention_status){
					hash = $(this).attr('data-hash');
					getBookingData(function(booking_json){
						chrome.tabs.create({
							url:'https://www.irctc.co.in/nget/train-search',
							active: true
						});
					}, hash);
				}
			});
		}

	});
	// updatePendingView();
})

$('#openNew').click(function(){
	if(true === extention_status){
		chrome.tabs.create({
			url:chrome.runtime.getURL('html/booking_form.html'),
			active: true
		});
	}
});

document.onkeyup = function(e) {
	if (e.which == 120) {
		$('[data-action="triggerBooking"]').trigger('click');
		// captchaBtn.click();
	}
	// else if (e.ctrlKey && e.which == 66) {
	// 	alert("Ctrl + B shortcut combination was pressed");
	// } else if (e.ctrlKey && e.altKey && e.which == 89) {
	// 	alert("Ctrl + Alt + Y shortcut combination was pressed");
	// } else if (e.shiftKey && e.which == 85) {
	// 	alert("Ctrl + Alt + Shift + U shortcut combination was pressed");
	// }
};


