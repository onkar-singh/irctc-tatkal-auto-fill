
let months = ["", "Monday", "Tuesday", "Wednesday", "Thrusday", "Friday", "Saturday", "Sunday"];
let quota = {"GN":"General","TK":"Tatkaal","PT":"Primium Tatkaal"};
let checkBox = ['confirm_berths','auto_upgradation','coach_preferred','auto_proceed'];
let radioBox = ['pay_mod', 'reservation_choice'];

let payment_opt = {
	"OPB": 	"Preferred Bank",
	"UPI": 	"BHIM/ UPI/ USSD",
	"MPS": 	"Multiple Payment Service",
	"DCP": 	"Debit Card with PIN",
	"ONB": 	"Net Banking",
	"WCC": 	"Wallets / Cash Card",
	"IRP": 	"IRCTC Prepaid",
	"COD": 	"Pay-On-Delivery/Pay later",
	"CDC": 	"Payment Gateway /Credit /Debit Cards"
};

var extention_status = false;
var card_tmpl = `
				<div class="col-sm-4 py-2 px-2">
					<div class="card card-dark">
						<div class="card-header px-2 py-1">
							<span><i class="far fa-eye mr-2 text-muted"></i><a class="link pointer" data-action="edit" data-hash="{{hash}}">{{form_name}}</a></span>
						</div>
						<div class="card-body p-2">
							<div class="row text-center font-weight-bold">
								<div class="col">{{from}}</div>
								<div class="col"><i class="fa fa-train"></i></div>
								<div class="col">{{to}}</div>
							</div>
							<p class="text-center p-0 m-0 text-md text-secondary"><strong>{{train_no}}</strong> : {{train_name}}</p>
							<div class="border-bottom my-2"></div>
							<div class="row">
								<div class="col text-center">
									<span class="badge badge-dark">{{j_date}}</span><br>
									<span class="text-uppercase">Adult</span><br>
									<span style="font-size: 25px;" class="font-weight-bold">{{psgn_count}}</span>
								</div>
								<div class="col text-center">
									<span class="badge badge-info text-uppercase">{{j_day}}</span><br>
									<span class="text-uppercase">Child</span><br>
									<span style="font-size: 25px;" class="font-weight-bold">{{psgn_ch_count}}</span>
								</div>
								<div class="col-sm-12 text-center">
									<span class="text-dark text-md text-uppercase font-weight-bold">{{class}}:{{quota}}</span>
								</div>
							</div>
							<div class="border-bottom my-2"></div>
							<div class="btn-group d-flex" role="group">
								<button class="btn btn-success btn-sm w-100" data-action="triggerBooking" data-hash="{{hash}}"><i class="fab fa-superpowers mr-2"></i>Book</button>
								<button class="btn btn-warning btn-sm w-100" data-action="edit" data-hash="{{hash}}"><i class="fa fa-edit mr-2"></i>Edit</button>
								<button class="btn btn-danger btn-sm w-100" data-action="delete" data-hash="{{hash}}"><i class="fa fa-trash-alt mr-2"></i>Delete</button>
							</div>
						</div>
					</div>
				</div>
				`;

function filter_staion_list(){
	var fsc = [];
	$.each(stations, function(k,v){
		sc = v.split("-");
		var f =[];
		f[0] = (sc[0].trim()).toUpperCase();
		f[1] = sc[1].replace("(","").replace(")","").trim().toUpperCase();
		fsc.push(f.join(" - "));
	});
}

$(function(){
	renderPaymentBlock();
	updatePendingView();
	hash = $_GET('hash');
	$('#extention_status').click(function(){
		if($('#extention_status').is(':checked') === true){
			setExtentionStatus('ON');
		}else{
			setExtentionStatus('OFF');
		}
	});
	checkExtentionSwitch();
	if(null !== hash)
		getBookingData(renderFormWithData, $_GET('hash'));
})

function renderPaymentBlock(){
	$('#payment-method-radio').html('');
	var permit_payment = ["DCP"];
	$.each(payment_opt, function(pc, ptext){
		// time_now = (new Date()).getTime();
		input_radio = $('<input/>').addClass('form-check-input').attr({
			'type': "radio",
			"name": "pay_mod",
			"id": "pay_mod_"+pc,
			"value": pc,
		});

		radio_label = $('<label/>').addClass('form-check-label').attr({
			"for": "pay_mod_"+pc
		}).text(ptext);
		// console.log(['Inarray = ',$.inArray(pc, permit_payment)]);
		if(-1 == $.inArray(pc, permit_payment)){
			input_radio.prop('disabled', true);
			radio_label.addClass('text-muted');
		}else{
			radio_label.addClass('text-success font-weight-bold');
		}

		p_opt = $('<div/>').addClass('form-check disabled')
		.append(input_radio)
		.append(radio_label);

		$('#payment-method-radio').append(p_opt);
	});
}

function setExtentionStatus(status = 'OFF'){
	// if($('#extention_status').is(':checked') === true)
	if(status === "ON"){
		chrome.storage.sync.set({extention_status: true}, function(){
			chrome.browserAction.setBadgeText({text: "ON"});
			extention_status = true;
		});
	}else{
		chrome.storage.sync.set({extention_status: false}, function(){
			chrome.browserAction.setBadgeText({text: "OFF"});
			extention_status = false;
		});
	}
}

function checkExtentionSwitch(){
	chrome.storage.sync.get(['extention_status'], function(result) {
		if(typeof result.extention_status != 'undefined')
			extention_status = result.extention_status;
		$('#extention_status').prop('checked', extention_status);
		chrome.browserAction.setBadgeText({text: (true === extention_status) ? 'ON' : 'OFF'});
	});
}

function $_GET(key){
	var url = new URL(window.location.href);
	var c = url.searchParams.get(key);
	return c;
}

function formValidate(){
	// $('#formName').focus();
	// return false;
	return true;
}

function updatePendingView(renderHash = null){
	$('#booking_card').html('');
	getBookingData(function(b_data){
		if(Object.keys(b_data).length > 0){
			console.log(b_data);
			$.each(b_data, function(k,v){
				// console.log(v.booking_form_name);
				html_temp = card_tmpl;
				temp = {
					hash: k,
					form_name: v.booking_form_name,
					from: ((v.from_station || '-').split('-')[1]).trim(),
					to: ((v.to_station || '-').split('-')[1]).trim(),
					train_no: v.train.split(":")[0].trim(),
					train_name: v.train.split(":")[1],
					j_date: v.j_date,
					j_day: months[(new Date(v.j_date)).getDay()],
					psgn_count: v.psngr.A.length,
					psgn_ch_count: v.psngr.C.length,
					class:v.coach_class,
					quota: quota[v.booking_quota]
				};

				$.each(temp, function(k,v){
					pattern = '{{' + k + '}}';
					regEx = new RegExp(pattern, 'g');
					html_temp = html_temp.replace(regEx, v);
				});

				$('#booking_card').append(html_temp);
			});
			$('[data-action="edit"]').click(function(){
				if(true === extention_status){
					hash = $(this).attr('data-hash');
					window.location.href = window.location.origin + window.location.pathname + "?hash=" + hash;
				}
				// getBookingData(renderFormWithData, hash);
			});

			$('[data-action="delete"]').click(function(){
				if(true === extention_status){
					hash = $(this).attr('data-hash');
					this_ = this;
					getBookingData(function(resp){
						last_node = (Object.keys(resp).length == 1)? true : false;
						delete resp[hash];
						chrome.storage.sync.get(['booking_default'], function(result) {
							updateJson = {"booking_data": resp};
							if(hash == btoa(result.booking_default.booking_form_name)){
								keys = Object.keys(resp);
								defaultJson = null;
								if(keys.length > 0){
									active_hash = keys[keys.length - 1];
									updateJson.booking_default = resp[active_hash];
								}
							// updateJson.booking_default = resp
						}
						chrome.storage.sync.set(updateJson, function(){
							$(this_).closest('.card').parent().remove();
							if(last_node)
								clearBookings();
						});
					});
					});
				}
			});

			$('[data-action="triggerBooking"]').click(function(){
				if(true === extention_status){
					hash = $(this).attr('data-hash');
					getBookingData(function(booking_json){
						chrome.tabs.create({
							url:'https://www.irctc.co.in/nget/train-search',
							active: true
						});
					}, hash);
				}
			});
		}
		else{
			clearBookings();
		}
	});
}

function clearBookings(){
	$('#booking_card').append($('<h1/>').html('Oops!!  Booking Data Not Found').addClass('text-center text-warning'));
}

// $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
//   e.target // newly activated tab
//   e.relatedTarget // previous active tab
// })

$(".station").autocomplete({
	max:10,
	minLength:3,
	source: availableStations_en,
	/*select: function (a, b) {
		var str = (b.item.value);
		console.log(str);
	}*/
});

$(".train").autocomplete({
	max:10,
	minLength:3,
	source: availableTrains_en,
	/*select: function (a, b) {
		var str = (b.item.value);
		console.log(str);
	}*/
});


$('#j_date').datepicker({
	uiLibrary: 'bootstrap4',
	minDate: 0,
	dateFormat: 'dd-mm-yy'
});

$('#booking_form').submit(saveBookingForm);

function saveBookingForm(){	;
	if(false === formValidate())
		return false;
	key = btoa($('#formName').val());
	getBookingData(function(booking_data){
		booking_data = booking_data || {};
		var status=true;
		if(typeof booking_data[key]!=='undefined'){
			//take user consent to proceed overriding data
			status = confirm('Form Name already present. Do you want to update?');
		}
		if(status === true){
			booking_data[key] = formJSON();
			chrome.storage.sync.set({booking_data: booking_data}, function() {
				/*$('#msgBox').show();
				$('#msgBox').alert();*/
				chrome.storage.sync.set({booking_default: booking_data[key]});
				alert('Your Form successfully saved with "'+ $('#formName').val() +'"');
				$('button[type="reset"]').trigger('click');
				updatePendingView();
				$('[href="#nav-pending"]').tab('show');
			});
		}
	});
	return false;
}

function formJSON(){
	var form_data = $('#booking_form').serializeArray();
	var	formJson = {
		"auto_upgradation": false,
		"auto_proceed": false,
		"confirm_berths": false,
		"coach_preferred": false,
		"psngr": {"C" :[], "A": []}
	};
	$.each(form_data, function(k,v){
		psgn_ch_match = (v.name).match(new RegExp(/^(psgn_ch)(\[)([\d])(\])(\[\')([a-z]+)(\'\])$/i));
		if(null !== psgn_ch_match && v.value != ''){
			if(typeof formJson['psngr']['C'][psgn_ch_match[3]] == 'undefined'){
				formJson['psngr']['C'][psgn_ch_match[3]] = {"name": "", "age" : "", "gender" : ""};
			}
			if(v.value != ''){
				formJson['psngr']['C'][psgn_ch_match[3]][psgn_ch_match[6]] = v.value;
			}else{
				delete formJson['psngr']['C'][psgn_ch_match[3]];
			}
		}
		else{
			/*console.log([
				v.name,
				v.value,
				$.inArray(v.name,options),
				'on' == v.value
			]);*/
			psgn_match = (v.name).match(new RegExp(/^(psgn)(\[)([\d])(\])(\[\')([a-z]+)(\'\])$/i));
			if(null !== psgn_match && v.value != ''){
				if(typeof formJson['psngr']['A'][psgn_match[3]] == 'undefined'){
					formJson['psngr']['A'][psgn_match[3]] = {"name": "", "age" : "", "gender" : "", "choice":""};
				}
				if(v.value != ''){
					formJson['psngr']['A'][psgn_match[3]][psgn_match[6]] = v.value;
				}else{
					delete formJson['psngr']['A'][psgn_match[3]];
				}
			}else if(-1 != $.inArray(v.name , checkBox) && 'on' == v.value){
				formJson[v.name] = true;

			}else if(null == psgn_match && null == psgn_ch_match){
				// console.log(v.name+"="+v.value);
				formJson[v.name] = v.value;
			}
		}
	});

	// console.log('Form Json = ');
	// console.log(formJson);
	return formJson;
}

function getBookingData(callback = false, key = false){
	chrome.storage.sync.get(['booking_data'], function(result) {
		var data = null;
		if(key !== false){
			data = result.booking_data[key];
		}else{
			data = result.booking_data;
		}
		if(callback !== false && data !== null){
			callback(data)
		}
	});
}

function renderFormWithData(json){
	$('[type="reset"]').trigger('click');
	$.each(json, function(k,v){
		if(k == 'psngr'){
			$.each(v, function(pk,pr){
				type = (pk == 'C') ? '_ch' : '';
				$.each(pr, function(x, r){
					$.each(r, function(rx, rc){
						// console.log(`[name="psgn`+ type +`[` + x + `]['` + rx + `']"]`);
						$(`[name="psgn`+ type +`[` + x + `]['` + rx + `']"]`).val(rc);
					});
				});
			});
		}else if(-1 != $.inArray(k, checkBox)){
			if(true == v){
				$('[name="'+k+'"]').attr({'checked': true});
			}
			console.log(v);
		}else if(-1 != $.inArray(k, radioBox)){
			// console.log('[name="'+k+'"] [value="'+v+'"]');
			$('[name="'+k+'"][value="'+v+'"]').attr({'checked': true});
		}else{
			$('[name="'+ k + '"]').val(v);
		}
	});
	$('[href="#nav-new"]').trigger('click');
}

$('#coach_preferred').click(function(e){
	if(true === $(this).is(':checked')){
		$('#coach_preferred_no').removeAttr('readonly');
	}
	else{
		$('#coach_preferred_no').attr('readonly', true);
	}
});