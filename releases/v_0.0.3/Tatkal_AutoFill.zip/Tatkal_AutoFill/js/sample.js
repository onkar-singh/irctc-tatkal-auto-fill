javascript: function E() {
    userId = document.getElementById("userId");
    pwd = document.getElementById("pwd");
    fromStation = document.querySelectorAll("[placeholder='From*']")[0];
    toStation = document.querySelectorAll("[placeholder='To*']")[0];
    journeydate = document.querySelectorAll("[placeholder='Journey Date(dd-mm-yyyy)*']")[1];
    flexiDate = document.getElementById("dateSpecific");
    fpsgname = document.querySelectorAll("[id='psgn-name']");
    fpsgage = document.querySelectorAll("[formcontrolname='passengerAge']");
    fpsggender = document.querySelectorAll("[formcontrolname='passengerGender']");
    fpsgberthchoice = document.querySelectorAll("[formcontrolname='passengerBerthChoice']");
    passFoodChoice = document.querySelectorAll("[formcontrolname='passengerFoodChoice']");
    fsrctzn = document.querySelectorAll("[id='srctzn-option']");
    childBerthFlag = document.querySelectorAll("[formcontrolname='childBerthFlag']");
    childName = document.querySelectorAll("[id='infant-name']");
    childAge = document.querySelectorAll("[formcontrolname='age']");
    childGender = document.querySelectorAll("[formcontrolname='gender']");
    mobileNumber = document.getElementById("mobileNumber");
    gstnumber = document.getElementById("gstin-number");
    autoUpgradation = document.getElementById("autoUpgradation");
    confirmberths = document.getElementById("confirmberths");
    nginvalid = document.getElementsByClassName(".ng-invalid");
    transPassword = document.querySelectorAll("[formcontrolname='txnPassword']");
    reservationChoice = document.querySelectorAll("[formcontrolname='reservationChoice']");
    for (var i = 0; i < nginvalid.length; i++) {
        nginvalid[i].classList.remove('ng-invalid');
        nginvalid[i].classList.add('ng-valid');
    }

    function F1(el, val) {
        if (document.getElementById(el) && val != '') document.getElementById(el).value = val;
    }
    if (document.forms['loginFormId']) {
        F1('usernameId', 'patelnawad');
        document.getElementsByClassName('loginPassword').j_password.value = 'XXX';
    };
    if (userId) {
        userId.value = 'patelnawad';
        userId.dispatchEvent(new Event('input'));
    }
    if (pwd) {
        pwd.value = 'M3797';
        pwd.dispatchEvent(new Event('input'));
    }
    if (fromStation) {
        fromStation.value = 'PATNA JN - PNBE';
        fromStation.dispatchEvent(new Event('keydown'));
        fromStation.dispatchEvent(new Event('input'));
    }
    if (toStation) {
        toStation.value = 'JALANDHAR CITY - JUC';
        toStation.dispatchEvent(new Event('keydown'));
        toStation.dispatchEvent(new Event('input'));
        toStation.click();
    }
    if (journeydate) {
        journeydate.value = '22-7-2018';
        journeydate.dispatchEvent(new Event('keydown'));
        journeydate.dispatchEvent(new Event('input'));
    }
    if (fpsgname[0]) {
        fpsgname[0].value = 'ANJU KUMARI';
        fpsgname[0].dispatchEvent(new Event('input'));
    }
    if (fpsgage[0]) {
        fpsgage[0].value = '48';
        fpsgage[0].dispatchEvent(new Event('input'));
    }
    if (fpsggender[0]) {
        fpsggender[0].value = 'F';
        fpsggender[0].dispatchEvent(new Event('change'));
    }
    if (fpsgname[1]) {
        fpsgname[1].value = 'DURSHITA RAJ';
        fpsgname[1].dispatchEvent(new Event('input'));
    }
    if (fpsgage[1]) {
        fpsgage[1].value = '26';
        fpsgage[1].dispatchEvent(new Event('input'));
    }
    if (fpsggender[1]) {
        fpsggender[1].value = 'F';
        fpsggender[1].dispatchEvent(new Event('change'));
    }
    if (mobileNumber) {
        mobileNumber.value = '7280985998';
        mobileNumber.dispatchEvent(new Event('change'));
    }
    if (autoUpgradation) {
        autoUpgradation.checked = true;
        autoUpgradation.removeAttribute('disabled');
    }
    if (confirmberths) {
        confirmberths.checked = true;
        confirmberths.removeAttribute('disabled');
    }
    if (document.getElementById('r4')) {
        document.getElementById('r4').checked = true;
    }
    try {
        if (document.getElementById('ui-tabpanel-3-label')) eval(document.getElementById('ui-tabpanel-3-label').click());
    } catch (err) {}
    try {
        if (document.getElementById('credit_3')) document.getElementById('credit_3').click();
    } catch (err) {}
}
E()